#main.py
def hello():
    print("hello from ")